def calc_tax():
    print("hello")
    pass
def calc_shipping():
    pass
